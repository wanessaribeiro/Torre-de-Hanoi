package com.br.hanoi.teste;

import java.util.Stack;

public class Principal {

	public static void main(String[] args) {
		
		Stack<Integer> p1 = new Stack<Integer>();
		Stack<Integer> p2 = new Stack<Integer>();
		Stack<Integer> p3 = new Stack<Integer>();

		p1.push(4);
		p1.push(3);
		p1.push(2);
		p1.push(1);
		
		System.out.println("Pilha 1:" + p1);
		System.out.println("Pilha 2:" + p2);
		System.out.println("Pilha 3:" + p3);
		
		Hanoi(p1.size(), p1, p3, p2);
		
		
		
	}
	
	public static void Hanoi(int n, Stack<Integer> original, Stack<Integer> des, Stack<Integer> aux) {
		
		if(n > 0) {
			
			Hanoi(n-1, original, aux, des);
			des.push(original.pop());
			System.out.println("------");
			System.out.println("Pilha 1:" + original);
			System.out.println("Pilha 2:" + aux);
			System.out.println("Pilha 3:" + des);
			Hanoi(n-1, aux, des, original);
		}
	}

}
